import { db } from "@workspace/db";
import {
  usersTable,
  transactionsTable,
  gameSessionsTable,
  pvpChallengesTable,
  depositAddressesTable,
  type User,
  type Transaction,
  type DepositAddress,
} from "@workspace/db";
import { eq, sql, desc, and, gte } from "drizzle-orm";

// ─── User Helpers ─────────────────────────────────────────────────────────────

export async function getOrCreateUser(
  telegramId: string,
  username?: string,
  firstName?: string,
  lastName?: string,
): Promise<User> {
  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.telegramId, telegramId))
    .limit(1);

  if (existing[0]) {
    await db
      .update(usersTable)
      .set({ username, firstName, lastName, updatedAt: new Date() })
      .where(eq(usersTable.telegramId, telegramId));
    return { ...existing[0], username: username ?? existing[0].username };
  }

  const inserted = await db
    .insert(usersTable)
    .values({ telegramId, username, firstName, lastName, chips: "0" })
    .returning();
  return inserted[0]!;
}

export async function getUserByTgId(telegramId: string): Promise<User | null> {
  const rows = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.telegramId, telegramId))
    .limit(1);
  return rows[0] ?? null;
}

export async function getUserById(id: number): Promise<User | null> {
  const rows = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export async function getChips(telegramId: string): Promise<number> {
  const user = await getUserByTgId(telegramId);
  return user ? parseFloat(user.chips) : 0;
}

export async function addChips(
  telegramId: string,
  amount: number,
  type: string,
  note?: string,
): Promise<number> {
  const user = await getUserByTgId(telegramId);
  if (!user) throw new Error("User not found");
  const newBalance = parseFloat(user.chips) + amount;
  await db
    .update(usersTable)
    .set({ chips: newBalance.toFixed(2), updatedAt: new Date() })
    .where(eq(usersTable.telegramId, telegramId));
  await db.insert(transactionsTable).values({
    userId: user.id,
    type,
    amount: Math.abs(amount).toFixed(2),
    status: "approved",
    note,
  });
  return newBalance;
}

export async function deductChips(
  telegramId: string,
  amount: number,
  type: string,
  note?: string,
): Promise<number> {
  return addChips(telegramId, -amount, type, note);
}

export async function setChips(telegramId: string, amount: number): Promise<void> {
  await db
    .update(usersTable)
    .set({ chips: amount.toFixed(2), updatedAt: new Date() })
    .where(eq(usersTable.telegramId, telegramId));
}

export async function banUser(telegramId: string, ban: boolean): Promise<void> {
  await db
    .update(usersTable)
    .set({ isBanned: ban, updatedAt: new Date() })
    .where(eq(usersTable.telegramId, telegramId));
}

// ─── Game Session Helpers ─────────────────────────────────────────────────────

export async function recordGame(
  telegramId: string,
  game: string,
  betAmount: number,
  payout: number,
  result: "win" | "loss" | "push",
  gameData?: Record<string, unknown>,
): Promise<void> {
  const user = await getUserByTgId(telegramId);
  if (!user) return;
  await db.insert(gameSessionsTable).values({
    userId: user.id,
    game,
    betAmount: betAmount.toFixed(2),
    payout: payout.toFixed(2),
    result,
    gameData: gameData ? JSON.stringify(gameData) : null,
  });
}

export async function getRecentGames(telegramId: string, limit = 5) {
  const user = await getUserByTgId(telegramId);
  if (!user) return [];
  return db
    .select()
    .from(gameSessionsTable)
    .where(eq(gameSessionsTable.userId, user.id))
    .orderBy(desc(gameSessionsTable.createdAt))
    .limit(limit);
}

// ─── Transaction Helpers ──────────────────────────────────────────────────────

export async function createDepositRequest(
  telegramId: string,
  crypto: string,
  cryptoAmount: string,
  txHash: string,
  walletAddress: string,
): Promise<Transaction> {
  const user = await getUserByTgId(telegramId);
  if (!user) throw new Error("User not found");
  const rows = await db
    .insert(transactionsTable)
    .values({
      userId: user.id,
      type: "deposit",
      amount: "0",
      crypto,
      cryptoAmount,
      txHash,
      walletAddress,
      status: "pending",
    })
    .returning();
  return rows[0]!;
}

/** Create a CryptoPay-based deposit — auto approved when payment confirmed */
export async function createCryptoPayDeposit(
  telegramId: string,
  crypto: string,
  cryptoAmount: string,
  invoiceId: string,
  invoiceUrl: string,
): Promise<Transaction> {
  const user = await getUserByTgId(telegramId);
  if (!user) throw new Error("User not found");
  const rows = await db
    .insert(transactionsTable)
    .values({
      userId: user.id,
      type: "deposit",
      amount: "0",
      crypto,
      cryptoAmount,
      txHash: invoiceId,          // store invoice ID as txHash
      walletAddress: invoiceUrl,  // store pay URL as walletAddress
      status: "pending",
      note: `CryptoPay invoice #${invoiceId}`,
    })
    .returning();
  return rows[0]!;
}

/** Find a pending deposit by CryptoPay invoice ID */
export async function findDepositByInvoiceId(invoiceId: string): Promise<Transaction | null> {
  const rows = await db
    .select()
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.txHash, invoiceId),
        eq(transactionsTable.status, "pending"),
      ),
    )
    .limit(1);
  return rows[0] ?? null;
}

export async function createWithdrawalRequest(
  telegramId: string,
  chips: number,
  crypto: string,
  walletAddress: string,
): Promise<Transaction> {
  const user = await getUserByTgId(telegramId);
  if (!user) throw new Error("User not found");
  const rows = await db
    .insert(transactionsTable)
    .values({
      userId: user.id,
      type: "withdrawal",
      amount: chips.toFixed(2),
      crypto,
      walletAddress,
      status: "pending",
    })
    .returning();
  return rows[0]!;
}

export async function getPendingTransactions() {
  return db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.status, "pending"))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(50);
}

/** Pending deposits only */
export async function getPendingDeposits() {
  return db
    .select()
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.type, "deposit"),
        eq(transactionsTable.status, "pending"),
      ),
    )
    .orderBy(desc(transactionsTable.createdAt))
    .limit(50);
}

/** Pending withdrawals only */
export async function getPendingWithdrawals() {
  return db
    .select()
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.type, "withdrawal"),
        eq(transactionsTable.status, "pending"),
      ),
    )
    .orderBy(desc(transactionsTable.createdAt))
    .limit(50);
}

/** Approved withdrawals from today */
export async function getApprovedWithdrawalsToday() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return db
    .select()
    .from(transactionsTable)
    .where(
      and(
        eq(transactionsTable.type, "withdrawal"),
        eq(transactionsTable.status, "approved"),
        gte(transactionsTable.createdAt, today),
      ),
    )
    .orderBy(desc(transactionsTable.createdAt))
    .limit(50);
}

export async function approveTransaction(txId: number, chipsAmount: number): Promise<Transaction> {
  const tx = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, txId))
    .limit(1);
  if (!tx[0]) throw new Error("Transaction not found");

  await db
    .update(transactionsTable)
    .set({ status: "approved", amount: chipsAmount.toFixed(2) })
    .where(eq(transactionsTable.id, txId));

  const user = await getUserById(tx[0].userId);
  if (user) {
    await db
      .update(usersTable)
      .set({
        chips: (parseFloat(user.chips) + chipsAmount).toFixed(2),
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, user.id));
  }
  return { ...tx[0], status: "approved" };
}

export async function rejectTransaction(txId: number, note?: string): Promise<Transaction> {
  const rows = await db
    .update(transactionsTable)
    .set({ status: "rejected", note })
    .where(eq(transactionsTable.id, txId))
    .returning();

  const tx = rows[0]!;
  if (tx.type === "withdrawal") {
    const user = await getUserById(tx.userId);
    if (user) {
      await db
        .update(usersTable)
        .set({
          chips: (parseFloat(user.chips) + parseFloat(tx.amount)).toFixed(2),
          updatedAt: new Date(),
        })
        .where(eq(usersTable.id, user.id));
    }
  }
  return tx;
}

// ─── Deposit Address Helpers ──────────────────────────────────────────────────

export async function getDepositAddresses(): Promise<DepositAddress[]> {
  return db
    .select()
    .from(depositAddressesTable)
    .where(eq(depositAddressesTable.isActive, true));
}

export async function getAllDepositAddresses(): Promise<DepositAddress[]> {
  return db.select().from(depositAddressesTable);
}

export async function upsertDepositAddress(
  crypto: string,
  label: string,
  address: string,
  network: string,
  minDeposit: number,
  chipsPerUnit: number,
): Promise<void> {
  await db
    .insert(depositAddressesTable)
    .values({
      crypto,
      label,
      address,
      network,
      minDeposit: minDeposit.toString(),
      chipsPerUnit: chipsPerUnit.toFixed(2),
      isActive: true,
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: depositAddressesTable.crypto,
      set: {
        label,
        address,
        network,
        minDeposit: minDeposit.toString(),
        chipsPerUnit: chipsPerUnit.toFixed(2),
        isActive: true,
        updatedAt: new Date(),
      },
    });
}

// ─── Admin Stats ──────────────────────────────────────────────────────────────

export async function getStats() {
  const [totalUsers] = await db
    .select({ count: sql<number>`count(*)` })
    .from(usersTable);
  const [totalChips] = await db
    .select({ sum: sql<string>`coalesce(sum(chips::numeric), 0)` })
    .from(usersTable);
  const [totalGames] = await db
    .select({ count: sql<number>`count(*)` })
    .from(gameSessionsTable);
  const [pendingTx] = await db
    .select({ count: sql<number>`count(*)` })
    .from(transactionsTable)
    .where(eq(transactionsTable.status, "pending"));
  return {
    totalUsers: Number(totalUsers?.count ?? 0),
    totalChips: parseFloat(totalChips?.sum ?? "0"),
    totalGames: Number(totalGames?.count ?? 0),
    pendingTx: Number(pendingTx?.count ?? 0),
  };
}

export async function getAllUsers(limit = 20) {
  return db
    .select()
    .from(usersTable)
    .orderBy(desc(usersTable.createdAt))
    .limit(limit);
}

// ─── PvP Helpers ─────────────────────────────────────────────────────────────

export async function createPvpChallenge(
  challengerTgId: string,
  game: string,
  betAmount: number,
  chatId: string,
) {
  const rows = await db
    .insert(pvpChallengesTable)
    .values({
      challengerTgId,
      game,
      betAmount: betAmount.toFixed(2),
      chatId,
      status: "pending",
    })
    .returning();
  return rows[0]!;
}

export async function acceptPvpChallenge(challengeId: number, challengeeTgId: string, messageId: number) {
  const rows = await db
    .update(pvpChallengesTable)
    .set({ challengeeTgId, status: "accepted", messageId })
    .where(eq(pvpChallengesTable.id, challengeId))
    .returning();
  return rows[0]!;
}

export async function completePvpChallenge(challengeId: number, winnerId: string, gameData: string) {
  const rows = await db
    .update(pvpChallengesTable)
    .set({ winnerId, status: "completed", gameData })
    .where(eq(pvpChallengesTable.id, challengeId))
    .returning();
  return rows[0]!;
}

export async function getPvpChallenge(challengeId: number) {
  const rows = await db
    .select()
    .from(pvpChallengesTable)
    .where(eq(pvpChallengesTable.id, challengeId))
    .limit(1);
  return rows[0] ?? null;
}
